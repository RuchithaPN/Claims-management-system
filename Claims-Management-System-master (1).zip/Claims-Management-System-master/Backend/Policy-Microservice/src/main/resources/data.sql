insert into policy (policy_No, policy_Name, policy_Benefits, tenure, premium)
values (1000, 'Jeevan', 'Cancer', 1000000, 10000);
insert into policy (policy_No, policy_Name, policy_Benefits, tenure, premium)
values (2000, 'Policy-Bazar', 'Dialysis', 15000, 1000);


insert into PolicyProvider (provider_Id, hospital_Name, location, policy_Id)
values (1, 'apollo', 'hyd', 1000);

insert into PolicyProvider (provider_Id, hospital_Name, location, policy_Id)
values (4, 'yashoda', 'chennai', 2000);