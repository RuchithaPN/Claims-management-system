export class Bills{
  memberId : String = '';
  premiumDue: number = 0;
  lastPaidDate: String = '';
  policyId: number = 0;
  dueDate: String = '';
  paymentDetails: String = '';
}

