insert into claim (claim_No, status, remarks, policy_Benefits, hospital_Name, benefits_Availed, amount, policy_Id, policy_Name)
values (10, 'Ongoing', 'NIL', 'Cancer', 'Apollo', 100000, 70000, 1000, 'Jeevan');
insert into claim (claim_No, status, remarks, policy_Benefits, hospital_Name, benefits_Availed, amount, policy_Id, policy_Name)
values (20, 'Claimed', 'NIL', 'Dialysis', 'Yashoda', 10000, 8000, 2000, 'Policy-Bazar');