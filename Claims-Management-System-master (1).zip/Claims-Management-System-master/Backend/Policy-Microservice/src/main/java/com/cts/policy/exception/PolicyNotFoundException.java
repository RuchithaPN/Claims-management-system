package com.cts.policy.exception;

public class PolicyNotFoundException extends Exception {

	public PolicyNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
