export class submitClaim{
  policyId: number = 0;
  policyName: String = '';
  policyBenefits: String = '';
  hospitalName: String = '';
  benefitsAvailed: number = 0;
  amount: number = 0;
}

