package com.cts.claim.exception;

public class TokenExpireException extends Exception {

	public TokenExpireException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
