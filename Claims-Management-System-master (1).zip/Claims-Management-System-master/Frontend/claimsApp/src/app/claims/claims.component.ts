import { Component } from '@angular/core';

@Component({
  selector: 'app-claims',
  templateUrl: './claims.component.html',
})
export class ClaimsComponent {}
