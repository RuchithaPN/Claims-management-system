export const environment = {
  production: true,
  AUTH_SERVICE_URL: 'http://localhost:8400/auth',
  MEMBER_SERVICE_URL: 'http://localhost:8430/member',
  CLAIM_SERVICE_URL:"http://localhost:8420/claim"
};
