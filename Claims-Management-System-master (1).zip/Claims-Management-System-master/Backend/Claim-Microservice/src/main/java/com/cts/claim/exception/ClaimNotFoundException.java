package com.cts.claim.exception;

public class ClaimNotFoundException extends Exception {

	public ClaimNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
