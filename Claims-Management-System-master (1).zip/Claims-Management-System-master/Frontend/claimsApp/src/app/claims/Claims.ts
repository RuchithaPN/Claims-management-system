export class Claims {
  claimNo: number=0;
  status: String = '';
  remarks: String = '';
  policyBenefits: String='';
  hospitalName: String='';
  benefitsAvailed: number=0;
  amount: number = 0;
  policyId: number= 0;
}
