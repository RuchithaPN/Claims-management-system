package com.cts.membermicroservice.exception;

public class MemberNotFoundException extends Exception {

	public MemberNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
