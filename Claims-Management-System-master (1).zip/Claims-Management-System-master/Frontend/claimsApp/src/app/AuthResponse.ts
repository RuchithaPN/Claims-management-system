export class AuthResponse{
    jwttoken:String='';
}