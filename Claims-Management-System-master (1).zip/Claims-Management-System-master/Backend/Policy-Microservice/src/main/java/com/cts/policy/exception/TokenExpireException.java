package com.cts.policy.exception;

public class TokenExpireException extends Exception {

	public TokenExpireException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
